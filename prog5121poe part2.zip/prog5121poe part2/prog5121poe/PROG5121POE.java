/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog5121poe;

/**
 *
 * @author lab_services_student
 */
public class PROG5121POE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int taskduration = 0;
  


   // new method
    loginCheck method = new loginCheck();
    
    // method decliration
    method.firstLastName();
    method.checkUserName("weeeeeeeee");
    method.checkPasswordComplexity("qwerty");
    method.registerUser();
    method.loginUser();
    method.returnLoginStatus(); 

    
    // Task class
    Task task = new Task( taskduration);
    //task.checkTaskDescription();
    //task.createTaskID();
    //task.printTaskDetails();
   // task.returnTotalHours();

   
        }
    
}
