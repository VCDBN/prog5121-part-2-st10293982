/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog5121poe;

import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
class loginCheck {
         String strUserName ="", strPassword = "" , strFirstName = "", strLastName = "", strgetUserName = "", strgetPassword = ""; 
   
   
    public void firstLastName(){
    strFirstName = JOptionPane.showInputDialog(null, "Enter First Name");
     strLastName = JOptionPane.showInputDialog(null, "Enter Last Name");
            
}
           boolean checkUserName(String we_e1){
    if ( strgetUserName.length()<=5 && strgetUserName.contains("_") ){
         return true;
     }
     else {
         return false;
     } 
}
         boolean checkPasswordComplexity(String qwerty){
   if ( strgetPassword.length()>=8) /* && strgetPassword.matches("QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890!@£$%^^&()_-+="  "(?=.*[A-Z]) (?=.*[a-z]) (?=.*[0-9])"  (?=.*!@#$%^&()_+?=<>.,;:|)" ) */
           {
           Pattern letter = Pattern.compile("[a-zA-z]");
        Pattern digit = Pattern.compile("[0-9]");
        Pattern special = Pattern.compile ("[!@#$%&*()_+=|<>?{}\\[\\]~-]");
   
           return true;    
            }  
    else {
       return false;
    }
}     
         String registerUser(){
          
       while(true){  
      strgetUserName = JOptionPane.showInputDialog(null,"Create your username");
      if (checkUserName("We_e1")){
        JOptionPane.showMessageDialog(null, "Username successfully captured");
       break;
        }
else {
            JOptionPane.showMessageDialog(null,  "Username is not " +
"correctly formatted, " +
"please ensure that " +
"your username " +
"contains an " +
"underscore and is no " +
"more than 5 " +
"characters in length .");
           continue;
        }
       
       }

       while(true){
    strgetPassword = JOptionPane.showInputDialog(null, "Create your Password");
  
 if (checkPasswordComplexity("qwerty")){
         JOptionPane.showMessageDialog(null, "Password successfully captured");
 break;
 }
     else
  {  JOptionPane.showMessageDialog(null, "“Password is not correctly formatted,  please ensure that " +
"the password " +
"contains at least 8 " +
"characters"
          + "/n a capital " +
"letter, a number and " +
"a special character.");
   continue;
    }   
  }        
       return null;
}
         
 boolean  loginUser(){
    if (strgetUserName.equals(strUserName) && strgetPassword.equals(strPassword)){
        return true;
    }
    else{
        return false ;
    }
       
}       
 //this took me forever "headache"
  public String returnLoginStatus(){

     while(true){
           strUserName = JOptionPane.showInputDialog( null,/*SigninBox,*/ "Enter your Username");
           strPassword = JOptionPane.showInputDialog( null,/*SigninBox,*/ "Enter your Password");

          if ( loginUser()){
              JOptionPane.showMessageDialog(null, "Welcome back " + strFirstName + " " +strLastName + " it is great to see you again. "  );
              break;
          }
          else{
              JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
          }
          }

          return null;
      }
    
}
