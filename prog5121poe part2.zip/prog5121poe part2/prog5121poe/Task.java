/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog5121poe;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
class Task {
    
    String Description = "";
    String TaskName ="";
    String DeveloperDetails ="";
    String id = "";
    int  TaskStatus = 0;
    
    int TotalTaskDuration = 0;
    int count = 0;
    int choice = 0;
    String input = "";
    
    
    private int duration;
    
    
    
    
     public Task(int taskduration){
        JOptionPane.showMessageDialog(null,"Welcome to EasyKanban");
     
       // int choice = 0; // initialize choice to a valid value
        while (choice != 3) { // loop until user chooses to quit
            // Display the menu and prompt the user to choose an option
             input = JOptionPane.showInputDialog("Menu:\n1. Add Task\n2. Show Report\n3. Quit");

            // Validate that the user has entered a valid input
            while (!input.matches("[1-3]")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid choice (1-3).");
                input = JOptionPane.showInputDialog("Menu:\n1. Add Task\n2. Show report\n3. Quit");
            }
        
        

            // Convert the input string to an integer
           choice = Integer.parseInt(input);

            switch (choice) {
                case 1:
                  
                    //the number of times you'd like to loop the program(the number of tasks you'd like to enter)
                      count = Integer.parseInt( JOptionPane.showInputDialog("Enter the number of tasks you'd like to add "));
                     
                     //limit the number of tasks you can enter at once
                     if( count <= 3){
      // for loop to equal the number of counts                  
      for (  int i = 0 ; i< count; i++){

                TaskName = JOptionPane.showInputDialog("Enter Task" + (i+1) + " Name:");
                DeveloperDetails = JOptionPane.showInputDialog("Enter the first and last name of the developer " +
                                                               "assigned to the task:");
                Description = JOptionPane.showInputDialog("Enter Task Description:");
                checkTaskDescription();
                
               taskduration = Integer.parseInt(JOptionPane.showInputDialog("Enter the estimated duration of the task1 in hours:"));
               
                TotalTaskDuration += taskduration;
                
                Object[]options = {"To Do "," Done", " Doing"};
                    TaskStatus = JOptionPane.showOptionDialog(null,"Task Status:","Very Importent Question",
            JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null, options, options[0]); 
         
                    createTaskID();
                    printTaskDetails();
                    returnTotalHours();
                 
          }
                 }   
                      else{
              JOptionPane.showMessageDialog(null, "You can only enter 3 tasks at once");
              
                }
                     break;
                     
                     case 2:
                   // Book.displayBookList();
                     JOptionPane.showMessageDialog(null, "Coming soon!");
                    break;

                case 3:
                    // Display goodbye message
                    JOptionPane.showMessageDialog(null, "Thank you for using the EasyKanban!");
                    break;

                default:
                    // Display error message for invalid choice
                    JOptionPane.showMessageDialog(null, "Please enter a valid choice (1-3).");
                    break;
     
            }     
          
        }
        
        this.duration = duration;
     }
      
    

            boolean checkTaskDescription(){
        
   if(choice == 1){
                   // description of task
                    

                    // limit the description to less the 50 charaters
                     while (true){
                    if( Description.length()>50){
                        
                        JOptionPane.showMessageDialog(null,"Please enter a task description of less than \n" +
                             "50 characters");
                      Description = JOptionPane.showInputDialog("Enter Task Description:");
                    } 
                    else{
                        JOptionPane.showMessageDialog(null,"Task successfully captured");
                    }
                    break;
                     }
   }
        return true;
      }
     
            
        String createTaskID(){
            if(choice == 1){
                
                    String tasknameprifix = TaskName.substring(0, 2).toUpperCase();
                    int devLength = DeveloperDetails.length() ;
                    String developerdetailprifix = DeveloperDetails.substring(devLength -3).toUpperCase();
                    id = tasknameprifix + ":" + count + ":" + developerdetailprifix;
                }
            
        return null;
      }
        
                       int returnTotalHours(){
                        if(choice == 1){
                            JOptionPane.showMessageDialog(null,"Total Task Duration: "  + TotalTaskDuration + "Hrs");
         return duration;
         
                        }
        return 0;
      }  

 String printTaskDetails(){
     
     if(choice == 1){
         
       
         
                if(TaskStatus == 0){
                    
                        JOptionPane.showMessageDialog(null,"Task Status: To Do" + "\n Task Number: " + count +"\n Task Name: " + TaskName + "\n Developer Name and Surname: " 
                                + DeveloperDetails + "\n Task Description: " + Description + "\nTask ID: " + id + "\nTotal Task Duration: " + TotalTaskDuration + "Hrs");

                }
                else if(TaskStatus == 1){
                        JOptionPane.showMessageDialog(null,"Task Status: Done" + "\n Task Number: " + count +"\n Task Name: " + TaskName + "\n Developer Name and Surname: " 
                                + DeveloperDetails + "\nTask ID: " + id + "\n Task Description: " + Description + "\nTotal Task Duration: "  + TotalTaskDuration + "Hrs");

      }
                else{
                        JOptionPane.showMessageDialog(null,"Task Status: Doing" + "\n Task Number: " + count +"\n Task Name: " + TaskName + "\n Developer Name and Surname: " 
                                + DeveloperDetails + "\n Task Description: " + Description + "\nTask ID: " + id + "\nTotal Task Duration: "  + TotalTaskDuration + "Hrs");

                }
   
     }
        return null;
                 
      }
 }
            
    

    
    

